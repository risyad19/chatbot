const socket = io.connect("http://25.14.116.95:8080");
var clid = "";

function sendChat() {
	var newmsg = document.getElementById("chat_message").value;
	// var nameVal = $( "#nameInput" ).val();
	//var clisess = sessionStorage.getItem("clidcuroag");
	if(newmsg != "" && newmsg != "\n") {
		socket.emit('messages', { chatmsg: newmsg });
		document.getElementById("chat_message").value = "";
	}
}

$("#chat_message").keypress(function(event) {
	if (event.keyCode === 13) {
		var newmsg = document.getElementById("chat_message").value;
		// var nameVal = $( "#nameInput" ).val();
		//var clisess = sessionStorage.getItem("clidcuroag");
		if(newmsg != "") {
			socket.emit('messages', { chatmsg: newmsg });
			document.getElementById("chat_message").value = "";
		}
	}
});

socket.on('connect', function(data) {
    // socket.emit('join', 'Hello World from client');
    clid = socket.id;
 });

socket.on('newins', function(data) {
	
	let value = data.ctroom+"|*|"+data.ctfromid+"|*|"+data.ctfromnm+"|*|"+
	data.cttoid+"|*|"+data.cttonm+"|*|"+data.ctmsg+"|*|"+data.cttime; // this could also be object/array/whatever
	let password = ''; //'Y2hhdGJvdGFqaWNhaHlh';
	let encr = CryptoJSAesJson.encrypt(value, password);
	
	let parm = { parms : encr }
	$.ajax({
			url : "service/sess.php",
			type: "POST",
			data : parm,
			success: function(data, textStatus, jqXHR) {
			var js  = JSON.parse(data);
			var stt = js['status'];
			var ctchat = js['ctchat'];
			var cttime = js['cttime'];
			if(stt == "1") {
				hideChat(1);
				var comHead = "<div class='chat_header'>"+
				"<div class='chat_option'>"+
				"<div class='header_img'>"+
				"<img class='agent' src='assets/images/agent-avatar.jpg'/>"+
				"</div>"+
				"<span id='chat_head'>Live Chat</span> <br> <span class='agent'>Layanan Pelanggan kami tersedia.</span>"+
				"<span class='chat_menu_loader'><i class='fullscreen zmdi zmdi-widgets'></i></span>"+
				"</div>"+
				"</div>";
				$( "div.fab_comp_head" ).replaceWith(comHead);

				var comChat = "<div class='fab_field fab_field2'>"+
				"<a id='fab_camera' class='fab is-visible'>"+"<i class='zmdi zmdi-camera'>"+"</i>"+"</a>"+
				"<a id='fab_send' class='fab is-visible' onClick='sendChat();'>"+"<i class='zmdi zmdi-mail-send'>"+"</i>"+"</a>"+
				"<a id='fab_emoji' class='fab is-visible' >"+"<i class='zmdi zmdi-mood'>"+"</i>"+"</a>"+
				"<textarea id='chat_message' name='chat_message' placeholder='Send a message' class='chat_field chat_message'>"+"</textarea>"+
				"</div>";
				$( "div.fab_comp_chat" ).replaceWith(comChat);

				var msg = '<span class="chat_msg_item chat_msg_item_user">'+
				ctchat+'</span>'+
				'<span class="status">'+cttime+'</span>';
					document.getElementById("chat_hist").innerHTML = msg;
      			var elmt = document.getElementById("chat_converse");
		  		elmt.scrollTop = elmt.scrollHeight;
			}

			},
			error: function (jqXHR, textStatus, errorThrown) {
	
			}
	});

	// console.log(data);
});

socket.on('newmsg', function(data) {
	const now  =  new Date();
	const time = date.format(now,'HH:mm');

	let ctmsg = data.ctmsg;
	
	var msg = '<span class="chat_msg_item chat_msg_item_user">'+
	ctmsg+'</span>'+
	'<span class="status">'+time+'</span>';
		// document.getElementById("chat_hist").innerHTML = msg;
		$("#chat_hist").append(msg);
	var elmt = document.getElementById("chat_converse");
	elmt.scrollTop = elmt.scrollHeight;
});

$('#chat_first_screen').click(function(e) {
	e.preventDefault();
	let ustokn = $("#frm_ustoken" ).val();
	let usmail = $("#frm_usermail" ).val();
	let usphno = $("#frm_userphno" ).val();
	let usname = $("#frm_username" ).val();
	let usques = $("#frm_userques" ).val();
	socket.emit('newchat', { ustokn: ustokn, usmail: usmail, usphno: usphno, usname: usname, usques: usques } );
});

socket.on('onsocket', function (data) {
	console.log('client onsocket !');
	// document.getElementById('chat_id').value = socket.id;
	// document.getElementById('chat_status').value = "1";
    // document.getElementById('view_status').innerHTML = "Anda Terhubung ke <b style='color: #007bff;'>Agent</b>.";
    // document.getElementById("chat_pict").style.backgroundImage = "url('customer-service.png')";
    // document.getElementById("chat_menu").style.display = "block";

    // var chatsesi = document.getElementById('chat_session').value;
    // socket.emit('register', {room: "A"}); //ini ke server untuk registrasi
});
