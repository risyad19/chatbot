<?php
$servername = "192.168.0.69";
$username = "es";
$password = "0218Galunggung";
$dbname = "db_cwbank_new";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>