<?php
require 'conf.php';
$arr = array();

if(isset($_POST['usmsg'])) {
    $us_msg = mysqli_real_escape_string($conn, $_POST['usmsg']);
    $arr['status'] = "1";
    $arr['message'] = "Success!";
    $arr['ctmsg'] = $us_msg;
}

$myJSON = json_encode($arr);
echo $myJSON;
?>