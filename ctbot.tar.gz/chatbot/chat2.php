<!doctype html>
<html lang="en">
    <head>

    </head>
    <body>
        <h1>Hello World!</h1>
        <div id="future"></div>
        <form id="form" id="chat_form" action="#">
            <input id="chat_input" type="text">
            <input type="submit" value="Send">
        </form>

        <script src="./node_modules/jquery/dist/jquery.js"></script>
        <script src="./node_modules/socket.io/client-dist/socket.io.js"></script>
        <script src="nodeClient.js"></script>
    </body>
</html>